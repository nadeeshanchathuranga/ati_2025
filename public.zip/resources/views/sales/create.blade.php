@extends('layouts.app')

@section('content')
<div class="container mt-5">

    <div class="row">
        <div class="col-lg-5">
<h1 class="text-white pb-3">
    Customer Details
</h1>


        <div class="mb-3">
            <label for="name" class="form-label text-white">Name</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Enter name">
        </div>

        <div class="mb-3">
            <label for="email" class="form-label text-white">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter email">
        </div>

        <div class="mb-3">
            <label for="phone" class="form-label text-white">Phone</label>
            <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter phone number">
        </div>




        </div>
        <div class="col-lg-7">
            <div class="billing-card">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Billing Details</h4>
 <a href="#" class="small text-decoration-none text-primary" data-bs-toggle="modal" data-bs-target="#userManualModal">
  User Manual <i class="bi bi-sliders"></i>
</a>

  </div>

  <!-- Barcode Entry -->

  <!-- Subtotal + Discount -->
  <div class="d-flex justify-content-between">
    <span>Sub Total</span>
    <span>0.00 LKR</span>
  </div>
  <div class="d-flex justify-content-between mb-3 small-label">
    <span>Discount</span>
    <span>( 0.00 LKR )</span>
  </div>

  <!-- Custom Discount -->
  <div class="mb-3">
    <label class="form-label">Custom Discount</label>
    <div class="input-group">
      <input type="number" class="form-control" placeholder="0.00">
      <select class="form-select" style="max-width: 80px;">
        <option>%</option>
        <option>LKR</option>
      </select>
    </div>
  </div>

  <!-- Cash -->
  <div class="mb-3">
    <label class="form-label">Cash</label>
    <div class="input-group">
      <input type="number" class="form-control" placeholder="0.00">
      <span class="input-group-text">LKR</span>
    </div>
  </div>

  <!-- Total -->
  <div class="d-flex justify-content-between">
    <strong>Total</strong>
    <strong>0.00 LKR</strong>
  </div>
  <div class="d-flex justify-content-between mb-3 small-label">
    <span>Balance</span>
    <span>0 LKR</span>
  </div>



  <!-- Payment Method -->
  <div class="mb-3">
    <label class="form-label">Payment Method :</label>
    <div class="d-flex gap-3">
      <div class="payment-option active text-center" onclick="selectPayment(this)">
        <img src="https://cdn-icons-png.flaticon.com/128/2331/2331966.png" alt="Cash" width="50">
      </div>
      <div class="payment-option text-center" onclick="selectPayment(this)">
        <img src="https://cdn-icons-png.flaticon.com/128/633/633611.png" alt="Card" width="50">
      </div>
    </div>
  </div>

  <!-- Confirm Button -->
  <button class="btn w-100 confirm-btn">● CONFIRM ORDER</button>
</div>
        </div>
    </div>
</div>


<!-- User Manual Modal -->
<div class="modal fade" id="userManualModal" tabindex="-1" aria-labelledby="userManualLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="userManualLabel">User Manual</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="overflow-auto" style="white-space: nowrap;">
    <div class="d-flex flex-row" style="gap: 1rem;">
        @foreach($teas as $tea)
           <div class="card h-100 border-dark tea-card" style="min-width: 300px; cursor: pointer;"
     data-tea-grade="{{ $tea->tea_grade }}"
     data-buy-price="{{ $tea->buy_price }}"
     data-selling-price="{{ $tea->selling_price }}">
    <div class="card-body">
        <h5 class="card-title text-uppercase">{{ $tea->tea_grade }}</h5>
        <p class="card-text mb-1"><strong>Buy Price:</strong> {{ number_format($tea->buy_price, 2) }} LKR</p>
        <p class="card-text mb-1"><strong>Selling Price:</strong> {{ number_format($tea->selling_price, 2) }} LKR</p>
        <p class="card-text mb-1"><strong>Date:</strong> {{ $tea->date }}</p>
    </div>
</div>
        @endforeach
    </div>
</div>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>













@endsection
<script>
  function selectPayment(element) {
    document.querySelectorAll('.payment-option').forEach(e => e.classList.remove('active'));
    element.classList.add('active');
  }
</script>
