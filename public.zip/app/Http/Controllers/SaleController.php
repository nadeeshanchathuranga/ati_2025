<?php

namespace App\Http\Controllers;
use App\Models\Tea;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\Customer;
use Illuminate\Http\Request;

class SaleController extends Controller
{
    public function index()
    {



        $sales = Sale::with('customer', 'items')->latest()->get();
        return view('sales.index', compact('sales'));
    }

    public function create()
    {
         $teas = Tea::where('status', '1')->get();
        $customers = Customer::all();
        return view('sales.create', compact('customers','teas'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'total_cost' => 'required|numeric',
            'cash' => 'required|numeric',
            'items.*.tea_id' => 'required|exists:teas,id',
            'items.*.quantity' => 'required|integer|min:1',
        ]);

        $sale = Sale::create([
            'customer_id' => $request->customer_id,
            'total_cost' => $request->total_cost,
            'cash' => $request->cash,
        ]);

        foreach ($request->items as $item) {
            SaleItem::create([
                'sales_id' => $sale->id,
                'tea_id' => $item['tea_id'],
                'quantity' => $item['quantity'],
            ]);
        }

        return redirect()->route('sales.index')->with('success', 'Sale created successfully!');
    }

    public function show(Sale $sale)
    {
        $sale->load('customer', 'items.tea');
        return view('sales.show', compact('sale'));
    }

    public function edit(Sale $sale)
    {
        $customers = Customer::all();
        $sale->load('items');
        return view('sales.edit', compact('sale', 'customers'));
    }

    public function update(Request $request, Sale $sale)
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'total_cost' => 'required|numeric',
            'cash' => 'required|numeric',
        ]);

        $sale->update($validated);

        // Optionally handle item updates...

        return redirect()->route('sales.index')->with('success', 'Sale updated.');
    }

    public function destroy(Sale $sale)
    {
        $sale->delete();
        return redirect()->route('sales.index')->with('success', 'Sale deleted.');
    }
}
