<?php $__env->startSection('content'); ?>
         <div class="container-fluid mt-5">
            <div class="container">
                <div class="row">
               <div class="col-lg-12 mx-auto">

   <h1 class="text-white fw-bolder text-center fs-4">Tea Price Index</h1>

          <?php if(session('success')): ?>
    <div class="alert alert-success" id="success-alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger" id="error-alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>




            <div class="mb-3 text-end">
                <a href="<?php echo e(route('teas.create')); ?>" class="btn btn-success">
                    <i class="fas fa-plus-circle"></i> Add New Tea
                </a>
            </div>


      <div class="table-responsive">


<table id="teaTable" class="table table-striped table-bordered table-hover align-middle">
    <thead class="table-success">
        <tr>
            <th>#</th> <!-- Index column -->
            <th>Tea Grade</th>
            <th>Buy Price (per 1g)</th>
            <th>Selling Price (per 1g)</th>
            <th>Date</th>
            <th>Status</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <tbody class="text-white fs-1-new">
        <?php $__currentLoopData = $teas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($index + 1); ?></td> <!-- Displaying index starting from 1 -->
            <td><?php echo e($tea->tea_grade); ?></td>
            <td><?php echo e($tea->buy_price); ?></td>
            <td><?php echo e($tea->selling_price); ?></td>
            <td><?php echo e($tea->date); ?></td>
            <td>
                <span class="badge <?php echo e($tea->status ? 'bg-success' : 'bg-secondary'); ?>">
                    <?php echo e($tea->status ? 'Active' : 'Inactive'); ?>

                </span>
            </td>
            <td class="text-center">
                <a href="<?php echo e(route('teas.edit', $tea->id)); ?>" class="btn btn-sm btn-outline-primary me-1">
                    <i class="fas fa-edit"></i>
                </a>
                <form action="<?php echo e(route('teas.destroy', $tea->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-outline-danger"
                        onclick="return confirm('Are you sure?')">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>





  </div>
            </div>
         </div>
         </div>
</div>
         <?php $__env->stopSection(); ?>

         <script>
  document.addEventListener("DOMContentLoaded", function () {
    new DataTable("#teaTable", {

      buttons: ["copyHtml5", "csvHtml5", "excelHtml5", "pdfHtml5"],
      responsive: true,
      paging: true,
    });
  });
</script>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\production_and_fertilizer_distribution\resources\views/teas/index.blade.php ENDPATH**/ ?>