<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 mx-auto">

                <h1 class="text-white fw-bolder text-center fs-4">Add New Supplier</h1>

                <form action="<?php echo e(route('suppliers.store')); ?>" method="POST" id="supplierForm">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <!-- Left Column -->
                        <div class="col-md-8 mx-auto">

                            <div class="mb-3">
                                <label class="text-white">Tea Grade</label>
                                <select name="tea_id" id="tea_id" class="form-control" required>
                                    <option value="">-- Select Grade --</option>
                                    <?php $__currentLoopData = $teas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tea->id); ?>" data-price="<?php echo e($tea->buy_price); ?>">
                                            <?php echo e($tea->tea_grade); ?> - 1g (<?php echo e($tea->buy_price); ?> Rs)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="text-white">Register ID</label>
                                <input type="text" name="register_id" class="form-control" value="<?php echo e($generatedRegisterId); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label class="text-white">Supplier Name</label>
                                <input type="text" name="supplier_name" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="text-white">Address</label>
                                <textarea name="address" class="form-control" rows="2" required></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="text-white">Phone Number</label>
                                <input type="text" name="phone_number" class="form-control" required
                                       pattern="^\d{10}$"
                                       maxlength="10"
                                       minlength="10"
                                       title="Phone number must be exactly 10 digits">
                            </div>


                            <div class="mb-3 text-end">
                                <button type="submit" class="btn btn-success px-4">Create Supplier</button>
                            </div>
                        </div>


                    </div>

                </form>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\production_and_fertilizer_distribution\resources\views/suppliers/create.blade.php ENDPATH**/ ?>