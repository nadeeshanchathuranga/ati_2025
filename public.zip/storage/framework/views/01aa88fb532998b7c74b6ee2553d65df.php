<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 mx-auto">

                <h1 class="text-white fw-bolder text-center fs-4">Fertilizer Price Index</h1>

                <?php if(session('success')): ?>
                    <div class="alert alert-success" id="success-alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger" id="error-alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <div class="mb-3 text-end">
                    <a href="<?php echo e(route('fertilizers.create')); ?>" class="btn btn-success">
                        <i class="fas fa-plus-circle"></i> Add New Fertilizer
                    </a>
                </div>

                <div class="table-responsive">
                    <table id="fertilizerTable" class="table   table-bordered table-hover align-middle">
                        <thead class="table-success">
                            <tr>
                                <th>#</th>
                                <th>Fertilizer Name</th>
                                <th>Stock (Kg)</th>
                                <th>Price (Rs)</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-white fs-1-new">
                            <?php $__currentLoopData = $fertilizers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fertilizer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($fertilizer->name); ?></td>
                                    <td><?php echo e($fertilizer->stock); ?></td>
                                    <td><?php echo e($fertilizer->price); ?></td>
                                    <td><?php echo e($fertilizer->date); ?></td>
                                    <td>
                                        <span class="badge <?php echo e($fertilizer->status == 'active' ? 'bg-success' : 'bg-secondary'); ?>">
                                            <?php echo e(ucfirst($fertilizer->status)); ?>

                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('fertilizers.edit', $fertilizer->id)); ?>" class="btn btn-sm btn-outline-primary me-1">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('fertilizers.destroy', $fertilizer->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger"
                                                onclick="return confirm('Are you sure? This will mark it as inactive.')">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        new DataTable("#fertilizerTable", {
            buttons: ["copyHtml5", "csvHtml5", "excelHtml5", "pdfHtml5"],
            responsive: true,
            paging: true,
        });
    });
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\production_and_fertilizer_distribution\resources\views/fertilizers/index.blade.php ENDPATH**/ ?>