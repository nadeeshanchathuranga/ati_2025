<?php $__env->startSection('content'); ?>
  <div class="container-fluid mt-5">
            <div class="container">
                <div class="row">
               <div class="col-lg-6 mx-auto">

   <h1 class="text-white fw-bolder text-center fs-4 pb-4">Edit Tea</h1>


    <form action="<?php echo e(route('teas.update', $tea->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-3">
            <label class="text-white">Tea Grade</label>
            <select name="tea_grade" class="form-control" required>
                <?php $__currentLoopData = ['BOP', 'FBOP', 'PEKOE', 'DUST']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($grade); ?>" <?php echo e((old('tea_grade', $tea->tea_grade) == $grade) ? 'selected' : ''); ?>>
                        <?php echo e($grade); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
          <label class="text-white">Buy Price (per 1g)</label>
            <input type="number" name="buy_price" value="<?php echo e(old('buy_price', $tea->buy_price)); ?>" class="form-control" step="0.01" required>
        </div>


          <div class="mb-3">
          <label class="text-white">Selling Price (per 1g)</label>
            <input type="number" name="selling_price" value="<?php echo e(old('selling_price', $tea->selling_price)); ?>" class="form-control" step="0.01" required>
        </div>

        
        <div class="mb-3">
            <label class="text-white">Date</label>
            <input type="date" name="date" value="<?php echo e(old('date', $tea->date)); ?>" class="form-control" required>
        </div>

        
        <div class="mb-3">
            <label class="text-white">Status</label>
            <select name="status" class="form-control">
                <option value="1" <?php echo e(old('status', $tea->status) == 1 ? 'selected' : ''); ?>>Active</option>
                <option value="0" <?php echo e(old('status', $tea->status) == 0 ? 'selected' : ''); ?>>Inactive</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\production_and_fertilizer_distribution\resources\views/teas/edit.blade.php ENDPATH**/ ?>