<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="col-md-6 mx-auto">
        <h2 class="text-center text-white mb-4">Add Tea Stock</h2>

        <form action="<?php echo e(route('tea_stock_store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label class="text-white">Supplier</label>
                <select name="supplier_id" class="form-control" required>
                    <option value="">-- Select Supplier --</option>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->supplier_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="text-white">Tea Weight (kg)</label>
                <input type="number" name="tea_weight" class="form-control" step="0.01" required>
            </div>

            <div class="mb-3">
                <label class="text-white">Date</label>
                <input type="date" name="date" class="form-control" required>
            </div>

            <div class="mb-3 text-end">
                <button type="submit" class="btn btn-success px-4">Add Stock</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\production_and_fertilizer_distribution\resources\views/suppliers/tea_stock_create.blade.php ENDPATH**/ ?>