<?php $__env->startSection('content'); ?>
<div class="container mt-5">
  

    <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary mb-3">Add New Sale</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Total Cost</th>
                <th>Cash Paid</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($sale->id); ?></td>
                <td><?php echo e($sale->customer->name); ?></td>
                <td><?php echo e($sale->total_cost); ?></td>
                <td><?php echo e($sale->cash); ?></td>
                <td><?php echo e($sale->created_at->format('Y-m-d')); ?></td>
                <td>
                    <a href="<?php echo e(route('sales.show', $sale->id)); ?>" class="btn btn-info btn-sm">View</a>
                    <form action="<?php echo e(route('sales.destroy', $sale->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\production_and_fertilizer_distribution\resources\views/sales/index.blade.php ENDPATH**/ ?>