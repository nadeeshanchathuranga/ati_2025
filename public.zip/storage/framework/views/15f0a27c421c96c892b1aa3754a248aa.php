<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <div class="container">
           <div class="row">
    <!-- Tea Price Card -->
    <div class="col-lg-2 d-flex">
        <div class="card text-center p-3 w-100 d-flex flex-column">
            <img src="<?php echo e(asset('images/tea-leaves.png')); ?>" class="card-img-top w-50 mx-auto mt-3" alt="Tea Leaves">
            <div class="card-body d-flex flex-column justify-content-between flex-grow-1">
                <h2 class="h4 fw-bold">Tea Price</h2>
                <a href="<?php echo e(route('teas.index')); ?>" class="btn btn-primary mt-3 px-1">Enter</a>
            </div>
        </div>
    </div>

    <!-- Supplier Card -->
    <div class="col-lg-2 d-flex">
        <div class="card text-center p-3 w-100 d-flex flex-column">
            <img src="<?php echo e(asset('images/supplier.png')); ?>" class="card-img-top w-50 mx-auto mt-3" alt="Supplier">
            <div class="card-body d-flex flex-column justify-content-between flex-grow-1">
                <h2 class="h4 fw-bold">Supplier</h2>
                <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-primary mt-3 px-1">Enter</a>
            </div>
        </div>
    </div>


      <div class="col-lg-2 d-flex">
        <div class="card text-center p-3 w-100 d-flex flex-column">
            <img src="<?php echo e(asset('images/in-stock.png')); ?>" class="card-img-top w-50 mx-auto mt-3" alt="Supplier">
            <div class="card-body d-flex flex-column justify-content-between flex-grow-1">
                <h2 class="h4 fw-bold">Tea Stock</h2>
                <a href="<?php echo e(route('tea_stock_store')); ?>" class="btn btn-primary mt-3 px-1">Enter</a>
            </div>
        </div>
    </div>


    <!-- Fertilizer Price Card -->
    <div class="col-lg-2 d-flex">
        <div class="card text-center p-3 w-100 d-flex flex-column">
            <img src="<?php echo e(asset('images/fertilizer.png')); ?>" class="card-img-top w-50 mx-auto mt-3" alt="Fertilizer">
            <div class="card-body d-flex flex-column justify-content-between flex-grow-1">
                <h2 class="h4 fw-bold">Fertilizer Price</h2>
                <a href="<?php echo e(route('fertilizers.index')); ?>" class="btn btn-primary mt-3 px-1">Enter</a>
            </div>
        </div>
    </div>



      <!-- Fertilizer Price Card -->
    <div class="col-lg-2 d-flex">
        <div class="card text-center p-3 w-100 d-flex flex-column">
            <img src="<?php echo e(asset('images/vendor.png')); ?>" class="card-img-top w-50 mx-auto mt-3" alt="Fertilizer">
            <div class="card-body d-flex flex-column justify-content-between flex-grow-1">
                <h2 class="h4 fw-bold">POS</h2>
                <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-primary mt-3 px-1">Enter</a>
            </div>
        </div>
    </div>
</div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\production_and_fertilizer_distribution\resources\views/dashboard.blade.php ENDPATH**/ ?>